## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)

## ----library_setup------------------------------------------------------------
library(WAFishBiology)
Fig_Path = "C:/~/WAFishBiology/vignettes/"

